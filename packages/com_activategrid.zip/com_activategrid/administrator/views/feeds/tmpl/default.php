<?php
/**
 * @version     1.0.0
 * @package     com_activategrid
 * @copyright   Copyright (C) 2014. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Andrea Falzetti <info@activatemedia.co.uk> - http://activatemedia.co.uk
 */


// no direct access
defined('_JEXEC') or die;
?>

<p></p>
<p><strong>Legend</strong>
<div><span class="label label-info">Item already imported</span></div>
<div><span class="label label-success">Item imported successfully</span></div>
<div><span class="label label-warning">Item not imported</span></div>
<div><span class="label label-important">Error during import / A copy in trash</span></div>
</p>